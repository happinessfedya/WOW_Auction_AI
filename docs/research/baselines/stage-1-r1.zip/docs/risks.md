# Риски, противоречия и неподтверждённые предположения

Этап 0, 26.10.2026, ревизия разработчика R2. Приоритеты: critical — ложное исполнение/капитал/неразрешённый переход; high — существенно неверный результат или заблокированная зависимость; medium — ухудшение полноты/восстановления. Обоснования по ID: [реестр](research-evidence.md). Наличие риска не означает доказанный runtime баг; пять дефектов спецификации S0-01–S0-05 признаны и исправляются в ответе R2, повторный вердикт остаётся за аудитором.

## Технические и источниковые

| ID / уровень | Факт или неопределённость | Последствие | Контроль / закрытие |
|---|---|---|---|
| R01 high | Ledger пуст и стар [L03–L04] | Нельзя подтвердить extraction/PnL реальных сделок | Непустая собственная история + invoice/CSV контроль; не переустановка наугад |
| R02 high | Ledger price net/unit, округление, mutable quantity, trimming [L05–L06] | Двойная комиссия/удвоение дохода/ложные удаления | Semantics fields, row revisions, multiset reconciliation, округление bounds |
| R03 high | Нет точных потерянных депозитов/полной связи покупка→изделие [L05]; проверенный Auctionator также не хранит deposit/duration/outcome [A02] | Реальная чистая прибыль неизвестна | Отдельная пометка затрат/ручные связи; не выдавать net sales за полный PnL |
| R04 critical | Несколько источников/персонажей показывают один warband; stale locations [L09–L13] | Раздутый доступный капитал | Ownership group, per-container reconciliation, unknown вместо двойного счёта |
| R05 high | BagSync теряет часть item link, binding и времён [L10] | Личная/непродаваемая вещь оценена как ликвидная | Торговый статус/вариант unknown, исключение equip, точечный будущий экспорт |
| R06 high | CraftSim API исходник существует, runtime/совместимость не проверены [C01–C10] | Неполные/старые расчёты | Собственный DTO, ready/error flags, game build/stat fingerprint, live comparison |
| R07 medium | C11 потенциально двойной expectedDeposit; C21 нулевой fallback | Ложная экономическая оценка CraftSim | Не объявлять defect доказанным; branch test в этапе 3, механика/рынок отдельно |
| R08 high | UE/Blizzard auth data ещё B [M02/M08] | Нет доказанной глубины/ID/полноты | Минимальные credentials probes; fallback capabilities понижаются |
| R09 high | Ключевые source data terms/30-day TTL спорны [M10] | Долгая история и полный replay могут быть недопустимы | Уточнение условий; retention policy по raw/derived, явный предел replay |
| R10 high | TSM conversion data all rights reserved; DB2 схемы ≠ дамп [C15–C20] | Нельзя обещать полный распространяемый seed | Разрешённые источники/право reuse, личный импорт только по условиям |
| R11 high | Lua/AppData могут содержать код, partial write, новые схемы; Auctionator strict UTF-8 не прошёл [A02] | Исполнение чужого кода/повреждённая нормализация | Только parser allowlist, bounds, сохранять raw bytes/encoding error; без replacement-декодирования ключей, quarantine, атомарный import |
| R12 high | Найденная SQLite 3.50.4 и документированный WAL-reset defect [E-TECH-01] | Возможная порча при соответствующей конкурентности | Исправленная сборка до WAL; сейчас ничего не обновлять; backup/recovery test |
| R13 medium | Нет измерения объёма полного рынка/истории | Нехватка диска/медленный анализ | Измерение этапа2, scope выбор, storage budget и видимые gaps |
| R14 high | Платные запросы/затраты провайдера задерживаются [E-AI-01] | Денежный лимит не точная гарантия | Disable, ограничение новых calls, provider statistics/unknown, без токен-бухгалтерии |
| R15 high | Внешний текст может содержать инструкции/ложные сведения | ИИ меняет правила/выводит секреты | Source isolation, evidence validator, hard gates вне LLM, backend secrets |
| R16 high | Коллекционный каталог/фильтрованные DB2 не полный экономический каталог; недоступные ветви и права могут скрыться за sample | Формально пройден T3-02 без широкого наполнения | [D2 traversal](research/transformation-discovery-r2.md), pinned corpus и disposition всех entries, metadata/sample/semantic completeness раздельно; blocked branches не PASS |

## Экономические и модельные

| ID / уровень | Риск | Проверка/защита |
|---|---|---|
| E01 critical | Цена объявления принята за исполнение; disappearance за продажу | unknown/conditional/scenario; отсутствие факта не даёт realized gain |
| E02 high | minBuyout на весь объём; TSM saleRate как личная probability | Depth C(q), quantity limits, отдельная калибровка ликвидности |
| E03 high | Неизвестная PMF заполнена равномерной; fractional expected yield продан как предмет | Joint discrete scenarios/unknown, mean не заменяет tail risk |
| E04 critical | Фантомный цикл или два пути тратят один ресурс | Баланс в каждом состоянии, общие cooldown/charges, conserved resources |
| E05 high | Пропущены ивенты/патч/предложение/конкуренция/время оборота | Конкурирующие hypotheses, controls, ablation, OOS и будущие наблюдения |
| E06 critical | Переобучение/look-ahead/ретроспективно исправленный прогноз | Actual-time/версия входа + immutable decision; режимы T2 отдельно, полный журнал вариантов; один available_at не очищает LLM weights |
| E07 high | Уверенная история ИИ заменяет причинность; прибыль подтверждает неверную причину | Аудит обоих знаков отклонения, фальсификаторы, unknown как допустимый итог |
| E08 high | «Независимые источники» копируют Blizzard snapshot | Lineage/upstream ID; не удваивать confidence |
| E09 high | Реальный остаток/перевод смешан с виртуальной доходностью | Раздельные книги и взносы; TSM gold delta не profit |
| E10 high | Требования персонажа пока не проверяются | Явное «исполнение персонажем не проверено», никаких рекомендаций как гарантированного действия |
| E11 high | Консервативная симуляция всё равно недоказуема | Отдельно lower bound/сценарии и чувствительность; не обещать реальную доходность |
| E12 high | Стратегия ухудшилась после успешных offline/shadow, старый fallback тоже устарел | MonitoringPolicy/ActivationEpisode, pause/no_new_risk, current revalidation; [SL2](research/strategy-lifecycle-r2.md) |
| E13 critical | Pause/rollback освобождает unknown in-flight или возвращает старый баланс; stale LLM выдаёт новый риск | Epoch fence, watermark, atomic/idempotent transition; origin/cost lots/committed events сохранены, open management отдельно |
| E14 high | Современная LLM знает будущий относительно backtest исход; memory/RAG аудитора содержит outcome | llm_historical_exploration не strict PiT/promotion evidence; stored replay не новый вызов; контекстный broker и prospective commit [T2](research/temporal-evaluation-r2.md) |
| E15 high | Поздний revised history/daily maximum ошибочно доступен утром; timestamp события выдан за публикацию | PublicationAvailabilityClaim точной revision, upper bounds/latency/period end; неизвестность исключает primary reconstruction, actual time неизменен |
| E16 high | Закрытый классификатор причин или always-unknown выдан за открытие нового фактора | Open ObservationRequest/FactorCandidate/novelty/temporal gates; positive и withheld arms слепого [F2](research/factor-discovery-r2.md) |

## Разногласия и выбранная трактовка

| ID | Столкновение | Трактовка с основанием |
|---|---|---|
| X01 | «Основной Undermine» в контексте vs требование проверить API/сменяемость | Пока кандидат. Blizzard как первичный снимок предлагается открыто; окончательный приоритет после реальных проб [sources.md](sources.md) |
| X02 | Stage1 упоминает CraftSim, Stage3 — расчётный движок/мост | Stage1 читает доступную структуру, Stage3 экспортирует реальные расчёты. Нет скрытого исключения CraftSim |
| X03 | Character stats нужны CraftSim, но проверка профессий пользователя отложена | Снимок крафтера для условного расчёта; не фильтр глобальной базы по доступности персонажу |
| X04 | «Все преобразования» vs нет полного реестра/PMF/прав | Максимально подтверждённый initial import всех категорий/дополнений, denominators по источникам, unknown totals, без 100% обещания |
| X05 | Длительный immutable replay vs source retention/удаление | Сохранение истории только в разрешённых пределах; unreplayable reason, не фиктивный replay по hash |
| X06 | Запрет автоматического /reload vs GX умеет autosave | Не включать/не вызывать функцию; найденное наличие не нарушает проект само по себе [L12] |
| X07 | Самокоррекция vs пользователь управляет этапами/стратегией | Этап0 только проект; будущая knowledge/strategy correction через раздельные gates. Рабочую версию не переписывать по одному исходу |
| X08 | Текущий клиент 12.1.5, TOC CraftSim/GX старше | Не считать ни исправностью, ни поломкой; runtime check до признания интеграции |
| X09 | «Подтверждённые вероятности» vs модельные предположения CraftSim/TSM | Использовать движок с provenance=model estimate; не повышать статус до игровых измерений без проверки |
| X10 | Unknown причина запрещает самокоррекцию vs требуется защита при ухудшении | Не менять модель по догадке; заранее согласованный supervisor может остановить новый риск независимо от причинного диагноза |
| X11 | История опубликована до решения, но получена приложением поздно | Exact actual replay исключает; conditional public reconstruction использует отдельный доказанный claim, не подменяет actual available_at |
| X12 | Старые inputs фильтрованы, но современная модель обучена позднее | Отдельный exploratory mode; новая LLM не получает strict badge только по внешним timestamp/prompt; будущее испытание обязательно |

Оставшиеся гипотезы: стабильность API разных версий, полнота разрешённых каталогов, годность экспортированного CraftSim для offline reprice, калибруемость ликвидности на малой истории, воспроизводимость learned causal factors. Они проверяются соответствующими критериями этапов, не принимаются фактом молча.
