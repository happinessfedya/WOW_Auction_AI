"""Bounded HTTPS transport. Credentials never enter diagnostics or redirects."""
from dataclasses import dataclass
from datetime import timezone
from email.utils import parsedate_to_datetime
import http.client
import math
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from collections.abc import Mapping

from .market_common import MarketError

ALLOWED_HOSTS = {'public-data.tradeskillmaster.com', 'api.undermine.exchange'}
SAFE_HEADERS = {'date', 'last-modified', 'etag', 'content-type', 'content-length',
                'content-encoding', 'retry-after', 'cache-control'}


@dataclass(frozen=True)
class HttpResponse:
    status: int
    body: bytes
    headers: dict
    received_at_ns: int
    elapsed_seconds: float
    wire_bytes: int


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def http_timestamp(value):
    if not value or not isinstance(value, str) or len(value) > 128:
        return None
    try:
        parsed = parsedate_to_datetime(value)
        if parsed.tzinfo is None:
            return None
        return max(0, int(parsed.astimezone(timezone.utc).timestamp()))
    except (ValueError, TypeError, OverflowError):
        return None


def retry_deadline(value, now_seconds):
    """Do not cap away a server's minimum delay; schedule it, never block sleep."""
    if isinstance(value, str):
        value = value.strip()
    if isinstance(value, str) and value.isascii() and value.isdecimal() and len(value) <= 1024:
        return now_seconds + int(value)
    timestamp = http_timestamp(value)
    return max(now_seconds, timestamp) if timestamp is not None else None


def _response_headers(headers, *, strict_framing=False):
    result = {}
    for key, value in (() if headers is None else headers.items()):
        key = key.lower()
        if key in SAFE_HEADERS:
            if strict_framing and key in {'content-length', 'content-encoding'} and key in result:
                raise MarketError('ambiguous_market_response_framing')
            result[key] = str(value)[:1024]
    return result


class HttpClient:
    def __init__(self, *, timeout=30, max_wire_bytes=64 * 1024 * 1024,
                 max_body_bytes=256 * 1024 * 1024, opener=None):
        if (type(timeout) not in (int, float) or not 1 <= timeout <= 60 or not math.isfinite(timeout)
                or type(max_wire_bytes) is not int or not 1 <= max_wire_bytes <= 256 * 1024 * 1024
                or type(max_body_bytes) is not int or not 1 <= max_body_bytes <= 512 * 1024 * 1024):
            raise MarketError('invalid_http_limits')
        self.timeout, self.max_wire_bytes, self.max_body_bytes = timeout, max_wire_bytes, max_body_bytes
        self.opener = opener or urllib.request.build_opener(NoRedirect())

    def request(self, url, *, headers=None, data=None, method='GET'):
        if (not isinstance(url, str) or not url or len(url) > 8192 or not url.isascii()
                or any(ord(character) <= 32 or ord(character) == 127 for character in url)):
            raise MarketError('untrusted_market_url')
        try:
            parsed = urllib.parse.urlsplit(url)
            if (parsed.scheme != 'https' or parsed.hostname not in ALLOWED_HOSTS or parsed.port not in (None, 443)
                    or parsed.username is not None or parsed.password is not None or parsed.fragment):
                raise ValueError
        except ValueError:
            raise MarketError('untrusted_market_url') from None
        if any(key.casefold() in {'access_token', 'client_secret', 'apikey', 'api_key', 'token'}
               for key, _ in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)):
            raise MarketError('credential_in_query_forbidden')
        if headers is not None and not isinstance(headers, Mapping):
            raise MarketError('invalid_http_header')
        actual = {'User-Agent': 'WoWAuctionIntelligence/0.2 local-market-reader', 'Accept-Encoding': 'gzip', **(headers or {})}
        seen = set()
        for key, value in actual.items():
            if (not isinstance(key, str) or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", key)
                    or key.lower() in {'host', 'proxy-authorization', 'content-length', 'transfer-encoding'}
                    or key.lower() in seen or not isinstance(value, str)
                    or any(ord(character) < 32 or ord(character) > 255 or ord(character) == 127 for character in value)):
                raise MarketError('invalid_http_header')
            seen.add(key.lower())
        if not isinstance(method, str) or method != 'GET' or data is not None:
            raise MarketError('unsupported_market_request')
        started = time.monotonic()
        request = urllib.request.Request(url, headers=actual, data=data, method=method)
        try:
            response = self.opener.open(request, timeout=self.timeout)
        except urllib.error.HTTPError as exc:
            # Error payloads can echo credentials. Never read/store/log them.
            try:
                metadata = _response_headers(exc.headers)
            finally:
                exc.close()
            return HttpResponse(exc.code, b'', metadata, time.time_ns(), time.monotonic() - started, 0)
        except (urllib.error.URLError, socket.timeout, OSError, http.client.HTTPException):
            raise MarketError('market_network_unavailable') from None
        try:
            with response:
                code = response.status
                metadata = _response_headers(response.headers, strict_framing=code == 200)
                if code != 200:
                    return HttpResponse(code, b'', metadata, time.time_ns(), time.monotonic() - started, 0)
                length = metadata.get('content-length')
                if length is not None:
                    if not length.isascii() or not length.isdecimal() or len(length) > 10:
                        raise MarketError('incomplete_market_response')
                    if int(length) > self.max_wire_bytes:
                        raise MarketError('market_wire_size_limit')
                encoding = metadata.get('content-encoding', 'identity').lower()
                if encoding not in {'gzip', 'identity'}:
                    raise MarketError('unsupported_content_encoding')
                decoder = zlib.decompressobj(16 + zlib.MAX_WBITS) if encoding == 'gzip' else None
                wire, size, parts = 0, 0, []
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    wire += len(chunk)
                    if wire > self.max_wire_bytes:
                        raise MarketError('market_wire_size_limit')
                    decoded = decoder.decompress(chunk, self.max_body_bytes - size + 1) if decoder else chunk
                    size += len(decoded)
                    if size > self.max_body_bytes or (decoder and decoder.unconsumed_tail):
                        raise MarketError('market_body_size_limit')
                    parts.append(decoded)
                if decoder and (not decoder.eof or decoder.unused_data):
                    raise MarketError('incomplete_or_concatenated_gzip')
                if length is not None and int(length) != wire:
                    raise MarketError('incomplete_market_response')
                return HttpResponse(code, b''.join(parts), metadata, time.time_ns(), time.monotonic() - started, wire)
        except (urllib.error.URLError, socket.timeout, OSError, http.client.HTTPException, zlib.error):
            raise MarketError('market_response_read_failed') from None
