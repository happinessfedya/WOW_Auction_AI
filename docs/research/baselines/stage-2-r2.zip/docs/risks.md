# Риски, противоречия и неподтверждённые предположения

Текущий реестр, 26.10.2026. Этап 0 R2 и подтверждённый объём этапа 1 приняты; этап 2 разрешён [D1](reviews/stage-1-review.md). S0-01–S0-05 и S1-01–S1-03 закрыты аудитом; внешние S1-V01–S1-V07 остаются в [сквозном реестре](reviews/open-verifications.md), не мешая независимой разработке. Приоритеты: critical — ложное исполнение/капитал/неразрешённый переход; high — существенно неверный результат или заблокированная зависимость; medium — ухудшение полноты/восстановления. Исторические обоснования: [реестр этапа 0](research-evidence.md). Наличие риска не означает доказанный runtime баг.

**Нормативное решение 26.10.2026:** пользователь исключил получение/использование Blizzard client ID/secret и прямой Blizzard API. Это не недостающий доступ, который следует запросить позднее. Текущие источники и компенсирующие ограничения — [матрица без Blizzard](research/stage-2-no-blizzard-alternatives.md). Исторические отчёты и исходные риски в архивных пакетах сохраняются.

## Технические и источниковые

| ID / уровень | Факт или неопределённость | Последствие | Контроль / закрытие |
|---|---|---|---|
| R01 high, частично снят | Прежний Ledger был пуст [L03–L04]; в R2/D1 уже проверены покупки, ремонт и Vendor sale, но не Auction sale/transfer/refund | Полный финансовый учёт/PnL не доказан, хотя непустой импорт работает | S1-V01–V03 по обычным доступным событиям и независимым свидетельствам; не переустановка, специальные сделки или повтор старого общего блокера |
| R02 high | Ledger price net/unit, округление, mutable quantity, trimming [L05–L06] | Двойная комиссия/удвоение дохода/ложные удаления | Semantics fields, row revisions, multiset reconciliation, округление bounds |
| R03 high | Нет точных потерянных депозитов/полной связи покупка→изделие [L05]; проверенный Auctionator также не хранит deposit/duration/outcome [A02] | Реальная чистая прибыль неизвестна | Отдельная пометка затрат/ручные связи; не выдавать net sales за полный PnL |
| R04 critical | Несколько источников/персонажей показывают один warband; stale locations [L09–L13] | Раздутый доступный капитал | Ownership group, per-container reconciliation, unknown вместо двойного счёта |
| R05 high | BagSync теряет часть item link, binding и времён [L10] | Личная/непродаваемая вещь оценена как ликвидная | Торговый статус/вариант unknown, исключение equip, точечный будущий экспорт |
| R06 high | CraftSim API исходник существует, runtime/совместимость не проверены [C01–C10] | Неполные/старые расчёты | Собственный DTO, ready/error flags, game build/stat fingerprint, live comparison |
| R07 medium | C11 потенциально двойной expectedDeposit; C21 нулевой fallback | Ложная экономическая оценка CraftSim | Не объявлять defect доказанным; branch test в этапе 3, механика/рынок отдельно |
| R08 high | UE authenticated данные ещё B [M02]; прямой Blizzard путь исключён пользователем | Нет REAL подтверждения UE depth/variants/history/cadence; TSM не компенсирует отсутствующие поля | TSM без ключа; UE DOC/MOCK до допустимого ApiKey/условий, затем реальные проверки доступных методов; Blizzard credentials не запрашивать |
| R09 high | Права TSM/UE на долгий raw/derived архив/передачу не подтверждены; M10 остаётся историческим upstream-контекстом | Долгая история и полный replay могут быть недопустимы | Политика по поставщику/артефакту; локальный TTL не правовое разрешение, отказ от прямого Blizzard не устраняет условия производных источников |
| R10 high | TSM conversion data all rights reserved; DB2 схемы ≠ дамп [C15–C20] | Нельзя обещать полный распространяемый seed | Разрешённые источники/право reuse, личный импорт только по условиям |
| R11 high | Lua/AppData могут содержать код, partial write, новые схемы; Auctionator strict UTF-8 не прошёл [A02] | Исполнение чужого кода/повреждённая нормализация | Только parser allowlist, bounds, сохранять raw bytes/encoding error; без replacement-декодирования ключей, quarantine, атомарный import |
| R12 high, ограничен выбранным режимом | Найденная SQLite 3.50.4 и документированный WAL-reset defect [E-TECH-01] | Возможная порча при соответствующей WAL-конкурентности | В принятом этапе 1 DELETE/FULL, WAL запрещён; backup/recovery проверены. До будущего WAL требуется исправленная сборка и отдельная проверка |
| R13 medium | Пять полных TSM CSV измерены; объём всего рынка/многодневной истории и UE ещё не подтверждён | Нехватка диска/медленный анализ при расширении scope | Раздельные замеры/политики этапа 2, storage budget и gaps; маленький per-item ответ/одна загрузка не доказательство общей нагрузки или cadence |
| R14 high | Платные запросы/затраты провайдера задерживаются [E-AI-01] | Денежный лимит не точная гарантия | Disable, ограничение новых calls, provider statistics/unknown, без токен-бухгалтерии |
| R15 high | Внешний текст может содержать инструкции/ложные сведения | ИИ меняет правила/выводит секреты | Source isolation, evidence validator, hard gates вне LLM, backend secrets |
| R16 high | Коллекционный каталог/фильтрованные DB2 не полный экономический каталог; недоступные ветви и права могут скрыться за sample | Формально пройден T3-02 без широкого наполнения | [D2 traversal](research/transformation-discovery-r2.md), pinned corpus и disposition всех entries, metadata/sample/semantic completeness раздельно; blocked branches не PASS |
| R17 high | Актуальный numeric connected ID не подтверждён; UE static realm-list и локальное имя мира не доказывают membership. LibRealmInfo даёт версионированный кандидат, не live-свидетельство | Ошибочное объединение аукционов или двойной учёт одного рынка | Provider+region+подтверждённый `request.realms`, evidence/hash/observed_at и версии; numeric ID не заполняется догадкой. Конфликты/изменения состава и cross-provider эквивалентность проверяются отдельно; DOC/MOCK не REAL |
| R18 high | Без прямого Blizzard каталога будущий discovery использует ATT и разрешённые build-данные | Пропуск неколлекционных рецептов, скрытых/серверных механик, variants или PMF | Полный согласованный pinned traversal и явные blocked/unknown ветви; отдельное доказательство механик; source completeness не глобальная полнота игры. Этап 3 ещё не разрешён |

## Экономические и модельные

| ID / уровень | Риск | Проверка/защита |
|---|---|---|
| E01 critical | Цена объявления принята за исполнение; disappearance за продажу | unknown/conditional/scenario; отсутствие факта не даёт realized gain |
| E02 high | minBuyout на весь объём; TSM saleRate как личная probability | Depth C(q), quantity limits, отдельная калибровка ликвидности |
| E03 high | Неизвестная PMF заполнена равномерной; fractional expected yield продан как предмет | Joint discrete scenarios/unknown, mean не заменяет tail risk |
| E04 critical | Фантомный цикл или два пути тратят один ресурс | Баланс в каждом состоянии, общие cooldown/charges, conserved resources |
| E05 high | Пропущены ивенты/патч/предложение/конкуренция/время оборота | Конкурирующие hypotheses, controls, ablation, OOS и будущие наблюдения |
| E06 critical | Переобучение/look-ahead/ретроспективно исправленный прогноз | Actual-time/версия входа + immutable decision; режимы T2 отдельно, полный журнал вариантов; один available_at не очищает LLM weights |
| E07 high | Уверенная история ИИ заменяет причинность; прибыль подтверждает неверную причину | Аудит обоих знаков отклонения, фальсификаторы, unknown как допустимый итог |
| E08 high | «Независимые источники» копируют Blizzard snapshot | Lineage/upstream ID; не удваивать confidence |
| E09 high | Реальный остаток/перевод смешан с виртуальной доходностью | Раздельные книги и взносы; TSM gold delta не profit |
| E10 high | Требования персонажа пока не проверяются | Явное «исполнение персонажем не проверено», никаких рекомендаций как гарантированного действия |
| E11 high | Консервативная симуляция всё равно недоказуема | Отдельно lower bound/сценарии и чувствительность; не обещать реальную доходность |
| E12 high | Стратегия ухудшилась после успешных offline/shadow, старый fallback тоже устарел | MonitoringPolicy/ActivationEpisode, pause/no_new_risk, current revalidation; [SL2](research/strategy-lifecycle-r2.md) |
| E13 critical | Pause/rollback освобождает unknown in-flight или возвращает старый баланс; stale LLM выдаёт новый риск | Epoch fence, watermark, atomic/idempotent transition; origin/cost lots/committed events сохранены, open management отдельно |
| E14 high | Современная LLM знает будущий относительно backtest исход; memory/RAG аудитора содержит outcome | llm_historical_exploration не strict PiT/promotion evidence; stored replay не новый вызов; контекстный broker и prospective commit [T2](research/temporal-evaluation-r2.md) |
| E15 high | Поздний revised history/daily maximum ошибочно доступен утром; timestamp события выдан за публикацию | PublicationAvailabilityClaim точной revision, upper bounds/latency/period end; неизвестность исключает primary reconstruction, actual time неизменен |
| E16 high | Закрытый классификатор причин или always-unknown выдан за открытие нового фактора | Open ObservationRequest/FactorCandidate/novelty/temporal gates; positive и withheld arms слепого [F2](research/factor-discovery-r2.md) |

## Разногласия и выбранная трактовка

| ID | Столкновение | Трактовка с основанием |
|---|---|---|
| X01 | Прежняя рекомендация прямого Blizzard снимка vs явный запрет пользователя | Прежняя рекомендация отменена. TSM — запуск без ключей, UE — условное расширение; отсутствие прямого snapshot/ID/variant detail видно в capabilities [матрицы](research/stage-2-no-blizzard-alternatives.md) |
| X02 | Stage1 упоминает CraftSim, Stage3 — расчётный движок/мост | Stage1 читает доступную структуру, Stage3 экспортирует реальные расчёты. Нет скрытого исключения CraftSim |
| X03 | Character stats нужны CraftSim, но проверка профессий пользователя отложена | Снимок крафтера для условного расчёта; не фильтр глобальной базы по доступности персонажу |
| X04 | «Все преобразования» vs нет полного реестра/PMF/прав | Максимально подтверждённый initial import всех категорий/дополнений, denominators по источникам, unknown totals, без 100% обещания |
| X05 | Длительный immutable replay vs source retention/удаление | Сохранение истории только в разрешённых пределах; unreplayable reason, не фиктивный replay по hash |
| X06 | Запрет автоматического /reload vs GX умеет autosave | Не включать/не вызывать функцию; найденное наличие не нарушает проект само по себе [L12] |
| X07 | Самокоррекция vs пользователь управляет этапами/стратегией | Сейчас разрешён только этап 2; будущая knowledge/strategy correction через раздельные gates. Рабочую версию не переписывать по одному исходу |
| X08 | Текущий клиент 12.1.5, TOC CraftSim/GX старше | Не считать ни исправностью, ни поломкой; runtime check до признания интеграции |
| X09 | «Подтверждённые вероятности» vs модельные предположения CraftSim/TSM | Использовать движок с provenance=model estimate; не повышать статус до игровых измерений без проверки |
| X10 | Unknown причина запрещает самокоррекцию vs требуется защита при ухудшении | Не менять модель по догадке; заранее согласованный supervisor может остановить новый риск независимо от причинного диагноза |
| X11 | История опубликована до решения, но получена приложением поздно | Exact actual replay исключает; conditional public reconstruction использует отдельный доказанный claim, не подменяет actual available_at |
| X12 | Старые inputs фильтрованы, но современная модель обучена позднее | Отдельный exploratory mode; новая LLM не получает strict badge только по внешним timestamp/prompt; будущее испытание обязательно |
| X13 | В D1 этап 1 принят, но часть REAL-сценариев не проверена | Принят подтверждённый объём, а не выдан полный REAL PASS. S1-V01–V07 пересматриваются на следующих аудитах и ограничивают только зависимые выводы, не возвращают общий запрет разработки |

После аудита этапа 2 R1 подтверждены S2-01–04: source-age/rollback, несогласованные HTTP validators, отсутствие общего deadline, влияние ненужного UE secret на TSM. Исправления и регрессии описаны в [ответе](review-responses/stage-2-r1-response.md); независимая повторная приёмка ещё требуется. Операционные пороги возраста 8h/48h/6h не являются измеренной cadence/SLA. S2-V01–V04 остаются открытыми, автоматически не переносятся по прежнему решению D1 этапа 1.

Оставшиеся гипотезы: стабильность API разных версий, полнота разрешённых каталогов, годность экспортированного CraftSim для offline reprice, калибруемость ликвидности на малой истории, воспроизводимость learned causal factors. Они проверяются соответствующими критериями этапов, не принимаются фактом молча.
