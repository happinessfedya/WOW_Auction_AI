"""Local read-only WoW data ingestion. Stage 1; no trading or network clients."""

__version__ = "0.1.0"
