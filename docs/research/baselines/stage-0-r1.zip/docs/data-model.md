# Независимая модель данных — проект, без миграций

Дата: 2026-10-26. Все таблицы ниже — спецификация будущей системы. Связанные документы: [архитектура](architecture.md), [экономика](research/economics-and-model-audit.md), [доказательства](research-evidence.md).

## Общие правила

Деньги в целых copper (`10000 copper = 1 gold`); исходная точность и округление сохраняются. Ожидания могут быть Decimal/рациональными числами, но остатки и исполненные количества целые. Не использовать binary float для денег. Неведомые значения — nullable с причиной, ноль — наблюдённый ноль. События append-only; исправления ссылаются на предыдущую запись. Импорт и построенные проекции разделены.

Пять независимых времён: `event_at` (момент события, если известен), `observed_at` (когда источник его увидел), `source_snapshot_at`, `received_at`, `available_at` (когда запись прошла проверку и стала доступна решению). Продажа и получение почты не один момент; TSM time может быть оценкой события из срока письма, с отдельными semantics/precision, а неизвестный event_at остаётся null. Дополнительно `valid_from/to` для механики и `recorded_at` для истории знания. Часы UTC, отображение Europe/Moscow/выбранный пояс, неопределённость часов хранится. Отсутствующий timestamp не заменяется mtime без метки `file_time_proxy`. В backtest требуется `available_at <= decision_at`; исторические выгрузки отдельно маркируют реконструированную доступность.

`file_written_at` хранится отдельно: proxy времени файла не повышает свежесть/приоритет наблюдения контейнера, если время его осмотра неизвестно. Для BagSync банк остаётся `observed_at=null` даже при новом mtime всего файла.

Каждое наблюдение хранит `source_id`, исходный ключ, hash/разрешённый payload locator, parser/schema/addon version, game build, статус доказательства, область полноты, срок хранения и причину недоступности. Числовая уверенность модели не заменяет категорию доказательств.

## Сущности и ключи

| Сущность | Основные поля и связи | Инвариант |
|---|---|---|
| Source, SourceCapability, SourceTerms | provider, version, URL/path template, auth kind, rate budget, allowed retention/redistribution, verified_at | Возможность и разрешение независимы; неизвестные права не становятся разрешением |
| ImportRun, RawObservation, DataGap | fingerprint, parser, start/end, status, errors, interval, expected/observed cadence | Повтор не меняет итог; ошибка не затирает хорошее наблюдение |
| Region, Realm, ConnectedRealmMembership | регион, числовые ID, локализованные имена/slug, effective interval | Связь realm→connected realm версионируется; строка имени не мировой ID |
| AccountScope, Character | локальный псевдоним, region, GUID если имеется, realm ID, display label | Имя персонажа не глобальный ключ; account-region scope не выводится только из имени папки |
| MarketScope | retail flavor, region, kind=`commodity/connected_realm`, connected ID nullable | Commodity требует null connected ID; connected требует ID; перенос между регионами не предполагается |
| ItemVariant | item ID, canonical bonus IDs, modifiers, context, quality/rank, level, pet species/level/breed/quality где применимо, raw item string | Не схлопывать варианты в base item; неизвестная эквивалентность остаётся отдельной |
| StorageOwner, Container | character/account-region/guild, kind bag/bank/warband/mail/auction/equipment, source container key | Warband принадлежит одному владельцу; guild не personal по умолчанию |
| AssetObservation, CashObservation | container, item/денежная единица, quantity, observed_at, complete flag, provenance | Две аддонные копии не складываются |
| ReconciledAsset, SourceConflict | selected observation, rejected alternatives, reconciliation rule/version, uncertain amount | Проекция объяснима; stale conflict не создаёт прибыль |
| RealLedgerEvent, LedgerRowRevision | собственный canonical ID, source snapshot/scope/family/ordinal/fingerprint, multiplicity, previous revision, type, item, qty, unit/total amount, price semantics gross/net, rounding bound, method, event-time semantics | Source ordinal/hash — provenance, не постоянный transaction ID; изменение агрегированного quantity TSM не новая полная сделка; net sale не облагается комиссией повторно |
| Transfer, EventLink, CostLot | связка внутренних перемещений/расходов/выручки, allocated quantity/cost, method, manual overlay | Перевод не доход; неизвестная себестоимость не ноль; оригинальный Ledger неизменён |
| MarketSnapshot | scope, source snapshot ID/time, fetched/available, complete/partial, truncation, retention | Агрегат не полная книга; пустой partial не исчезновение рынка |
| OfferLevel, AuctionOffer, MarketAggregate | unit price+quantity либо auction ID+total buyout+quantity; variant; min/recent/historical/type | `buyout` за лот и `unit_price` не взаимозаменяемы; агрегат не sale price |
| Transformation, TransformationVersion | тип, expansion, live Retail build, requirement expression, evidence, validity | Один и тот же рецепт в Classic не доказывает Retail |
| Input, OutputOutcome, OutcomeMember | item/currency/resource, qty, consume/retain, state branch, probability/distribution/evidence | Совместный исход целиком: quality/quantity/resourcefulness могут зависеть друг от друга |
| MechanicConstraint | limit amount/window/reset/timezone, character/account/global scope, charges, cooldown pool, condition | Две операции с общим cooldown расходуют один пул |
| AvailabilityClaim | tradeable/BoP/warbound, transfer restrictions, economic path requirement, known/unknown | Доступность профессии персонажу пока unknown; нельзя выдавать готовое исполнимое поручение |
| CrafterSnapshot, CraftEvaluation | recipe/crafter/build/CraftSim versions, stats, reagents/quality, spec fingerprint, buffs, concentration, mechanics outputs, pricing fingerprint, calculation_status=`ready/unsupported/missing_data/stale`, missing fields | `0,{}` без ready-контракта не доказанная нулевая прибыль; вероятности имеют provenance=model estimate либо подтверждение |
| CoverageCell | expansion×category×source/build, discovered/verified/eligible/unknown/quarantined, denominator known? | Если знаменатель неизвестен, нет процента полноты всей игры |
| StrategyVersion, ConstraintSet | immutable config, profiles, hard/soft, utility/risk preferences, approved values | ИИ не меняет hard constraints; предложенные значения не являются принятыми |
| DecisionSnapshot, Forecast | evidence set, features, quantitative targets/intervals, horizon, cancellation, confidence, omissions, versions | Insert фиксируется до будущего outcome; update заменён новой записью со ссылкой |
| VirtualPortfolio, VirtualEvent, Position, Reservation | scenario/execution model ID, initial NAV/cash/lots, contributions/withdrawals, cost transfers, wallet_cash, cash reservations, deposit_asset, deposit losses/refunds | Доступно wallet_cash−reservations; уже уплаченный залог не вычитается снова; NAV reconciliation отдельно от прибыли партии |
| ExecutionAssessment, OutcomeObservation | observed/conditional/unknown/scenario, partial fill, time/cost, assumptions, censoring | «Лот исчез» не `observed sale`; сценарные книги отдельно |
| ModelAudit, Hypothesis, EvidenceTest | конкурирующие причины, causal estimand, identification assumptions, confounders/spillovers, control validity, expected signature, falsifier, independent evidence, cause status, predictive utility status | Confirmed cause и полезность признака независимы; ablation сама по себе не causal proof; `unknown` допустим |
| StrategyExperiment, Promotion, Rollback | pre-registration, train/validation/test windows, embargo, metrics, number of trials, shadow start/end, decision | Нельзя продвигать по тому же периоду, на котором подобраны параметры |
| KnowledgeProposal, KnowledgeRevision | complaint/research origin, independent sources, patch check, tests, supersedes, affected chains | Карантин/откат версии; никакой бесследной правки |
| ScheduledJob, JobRun, ProviderSpendSnapshot | lease/retry/idempotency, due date, source cost data/as-of/error | Нет своей оценки долларов через подсчёт токенов |

## Связи, которые нельзя потерять

`Forecast → DecisionSnapshot → конкретные версии источников/механик/стратегии/исполнения` обеспечивает replay. `TransformationVersion → Input/Outcome/Constraint → ItemVariant/Resource` задаёт гиперграф. `VirtualEvent → Forecast → ExecutionAssessment` отличает рекомендацию от предполагаемого исполнения. `KnowledgeRevision → affected transformations → impacted forecasts` не переписывает прежние прогнозы, а добавляет ретроспективную пометку. `RealLedgerEvent → CostLot → ManualLink` сохраняет неизвестность связей, не создавая ложной точной прибыли.

## Дедупликация, оценки имущества и себестоимость

Ключ баланса: `(account scope, owner, container, item variant, observation generation)`. Account scope — подтверждённая группа общей собственности/регион, не просто папка SV или отдельная WoW-лицензия; связь нескольких лицензий с одним warband требует явного подтверждения. Согласование выполняется отдельно для cash/bag/bank/warband/auction/mail, с историей выбора. Контейнеры, которые аддон уже агрегирует, нельзя суммировать с их детализацией. Перемещение с задержкой снимков создаёт неоднозначность: общий капитал показывается диапазоном/неполным, а не сложением обоих мест.

Товарные запасы требуют классификации пользователя/правила торгуемости; экипировка исключается автоматически из торговли, BoP не ликвидный актив. Текущая котировка, консервативная стоимость реализации и историческая себестоимость — три разных показателя. Остатки суммировать только при совместимом срезе; на экране есть время каждого источника и неосмотренные хранилища.

Предложение для виртуальной книги: явные cost lots и FIFO как первая воспроизводимая политика, с конфигурацией/версией. Для реальной книги сначала точные доступные связи TSM, затем ручная связь; не достраивать неизвестную закупочную цену. Совместные продукты преобразования требуют отдельной политики распределения затрат; до её выбора прибыль считать по всей партии, а не оптимистически обнулять побочный продукт. Денежные взносы/изъятия в виртуальный портфель меняют капитал, не доходность.

## Варианты хранения и ограничение объёма

SQLite — метаданные, нормализованные рабочие выборки, очередь, портфели. Сжатые исходные HTTP/SV-пакеты — только в приватном разрешённом хранилище с правами и сроком хранения. Историю рыночных уровней делить по scope/дате, индексировать item/time; не обещать многолетние миллионы лотов в одном маленьком файле. На этапе 2 измерить `bytes/snapshot × snapshots/day × scopes × retention`, время импорта/переоценки и рост WAL. Агрегация не заменяет уровни для replay; если уровни удалены, это ограничение воспроизводимости видно пользователю.
