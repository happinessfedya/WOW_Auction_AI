# Критерии приёмки и фактические проверки

Дата: 2026-10-26. **Тестов приложения пока нет: приложение не реализуется в этапе 0.** Здесь разделены выполненные исследования и будущие обязательные проверки. Метки: REAL — фактические файлы/ответы; SOURCE — исходник/документация; SYN — синтетическая проверка; PLAN — ещё не запускалось; BLOCKED — требует конкретного внешнего условия. Mock/SYN никогда не заменяет REAL.

## Этап 0: выполнено и границы вывода

| ID | Проверка | Тип / результат | Доказательство |
|---|---|---|---|
| T0-01 | Все 6 файлов handoff + корневой README, ссылки/приоритет | REAL: прочитаны; существующего приложения нет | E-ENV-01/02, hashes входов |
| T0-02 | Путь Retail/build, TOC всех 5 основных аддонов и общая инвентаризация | REAL+SOURCE: 52 каталога/145 TOC; Auctionator gap-проверка | L01–L02, C01, A01–A02 |
| T0-03 | GX/BagSync структура и сопоставление денег | REAL: 2 персонажа, значения согласуются; неполное покрытие контейнеров | L03/L09/L11 |
| T0-04 | Ledger схемы/данные и net/unit семантика | SOURCE+REAL: 6 схем; 0 data rows; непустая сделка BLOCKED | L04–L08 |
| T0-05 | AppData scope/time/поля | REAL+SOURCE: 9 наборов, свежая запись, scope EU/мир | L14–L15 |
| T0-06 | CraftSim API/export/SV/model limits | SOURCE+REAL: API найден, lastCraftingCost пуст; runtime BLOCKED | C01–C12/C21 |
| T0-07 | TSM Public CSV | REAL: 3 HTTP200, схемы/count/timestamps/hash | M04–M05 |
| T0-08 | UE auth boundary и документация | SOURCE+REAL: контракт, HTTP401 без ключа; successful data BLOCKED | M01–M03 |
| T0-09 | Blizzard docs/OAuth/quota/transport | SOURCE+REAL документа: JSON200; data без Bearer404, auth BLOCKED | M08–M09 |
| T0-10 | Кандидаты преобразований/лицензии/покрытие | SOURCE: Retail tables и схемы, без semantic import | C14–C20 |
| T0-11 | Числовые ошибки экономики и временной доступности | SYN: результаты отдельного прогона | [stage0-checks.md](research/stage0-checks.md) |
| T0-12 | Внутренняя критическая вычитка | 2 субагента: замечания исправлены, не независимая приёмка | [отчёт](stage-0-report.md) |
| T0-13 | Документы/ссылки/отсутствие реализации | Фактический результат финальной проверки | [отчёт](stage-0-report.md) |

## Этап 1 — импорт, капитал, Ledger (все PLAN)

| ID | Вход и действие | Ожидаемый результат | Тип при реализации |
|---|---|---|---|
| T1-01 | Существующие GX/BagSync и ручная сверка кошелька/warband | Copper и 10000/gold, два источника не удваивают деньги, lastSeen отдельный | REAL |
| T1-02 | Два персонажа/две WoW-лицензии с одним warband | Один подтверждённый owner; неизвестное ownership не сливается автоматически | REAL+SYN |
| T1-03 | Неосмотренный банк, пустой полный банк, старый bank/new bags, перенос | Unknown отличается от нуля; stale locations не создают капитал | REAL+SYN |
| T1-04 | Экипировка, BoP, item variants/bonus/modifiers, pet | Личная/непродаваемая вещь исключена; потерянный variant unknown | REAL+SYN |
| T1-05 | Два чтения одного файла, изменение только mtime, `.bak` | Идемпотентность; резерв не второй актив | SYN+REAL |
| T1-06 | Partial write, синтаксическая ошибка, executable Lua, huge nesting, невалидные UTF-8 bytes | Нет исполнения/зависания/lossy replacement ключей; quarantine; последняя валидная версия сохранена | SYN; найденный A02 encoding случай если адаптер подключён |
| T1-07 | Sale invoice/непустая TSM CSV, buys, expenses, refunds, transfers | Net/unit и rounding bounds, event estimate отдельно; transfer/refund не profit | REAL обязательный |
| T1-08 | Mutable row quantity 2→3; одинаковые продажи; reorder/trim | Приращение 1 при подтверждённом matching, не +3; multiplicity; trimming не обратная сделка | SYN+REAL |
| T1-09 | Нет purchase cost/залогов/связи крафта | PnL unknown/partial; ручная связь overlay, TSM неизменён | SYN+REAL |
| T1-10 | Kill процесса между parse/commit/checkpoint, migration/restore | Atomic recovery без дублей; исправленная SQLite/безопасный режим | SYN |

## Этап 2 — рынок (все PLAN)

| ID | Вход и действие | Ожидаемый результат | Тип |
|---|---|---|---|
| T2-01 | Blizzard OAuth→realm→connected group→auctions/commodities | Подтверждённые IDs и правильные namespaces, никаких секретов в logs | REAL, Q02 |
| T2-02 | UE static + commodity/realm now + history с ключом | Schema/depth/quantity/clocks/paid capabilities; free недоступность явная | REAL, Q03 |
| T2-03 | TSM CSV minBuyout0, region historical/saleRate | Ноль не бесплатная покупка; scalar не timeline; не fictitious probability | REAL+SYN |
| T2-04 | Несколько естественных обновлений и repeated hash | Измеренная cadence; timestamps не подменяются receive time | REAL |
| T2-05 | Частичный снимок/пустой ответ/HTML вместо CSV/новая схема | Нельзя удалить весь рынок; quarantine/health видны | SYN |
| T2-06 | 401/403/429/5xx/timeout/Retry-After | Ограниченные retries, отсутствие storm, last good stale, downgrade capabilities | MOCK+REAL допустимой пробы |
| T2-07 | Сон/выключение, поздний backfill | Gap; received/available поздние; backtest не видит будущее | SYN+REAL |
| T2-08 | Один item, разные варианты/scopes и общий upstream | Нет ошибочного смешения/двойного confidence | REAL+SYN |
| T2-09 | Полный снимок и несколько выбранных scopes | Размер/скорость/рост storage измерены; policy retention соблюдена | REAL |
| T2-10 | Удаление по разрешённой политике, ссылка forecast на удалённые входы | `replay_unavailable_due_to_retention`; не ложный PASS replay | SYN, Q06 |

## Этап 3 — преобразования (все PLAN)

| ID | Вход и действие | Ожидаемый результат | Тип |
|---|---|---|---|
| T3-01 | Все страницы разрешённых profession/tier индексов всех Retail дополнений | Counts reconcile, checkpoints/retry, каждая expansion×category в отчёте | REAL |
| T3-02 | Nonprofession families: DE/mill/prospect/transmute/use/container/NPC/currency/special | Первичный подтверждённый batch каждой доступной семьи, пробелы/права/unknown totals явные | REAL, внешние источники |
| T3-03 | Classic rows, устаревший рецепт, неизвестный reagent/PMF | Не выдается confirmed-current/надёжной рекомендацией | SYN+REAL |
| T3-04 | CraftSim ready event→собственный SV→ручной flush | Совпадение input/output/quality/stats/prices с движком; чужие SV неизменны | REAL, Q05 |
| T3-05 | Gear/spec/buffs/price/reagent/build/concentration changes | Fingerprint invalidation, stale/unsupported/missing_data; `0,{}` не valid0 | REAL+SYN |
| T3-06 | C11 deposit branch и fixed variant offline repricing | Проверено количество вычетов и units; механика движка сохранена, допущения названы | REAL+SYN |
| T3-07 | Joint outcomes/мелкая партия/неувиденный редкий выход | Не дробный физический предмет; mean не PMF; неизвестность не uniform | SYN |
| T3-08 | Weekly diff/patch event/feedback, одинаковые материалы повторно | Changed subset; evidence current independent; новая версия+rollback; no duplicate AI research | MOCK+REAL |

## Этап 4 — экономика (все PLAN)

| ID | Вход и действие | Ожидаемый результат | Тип |
|---|---|---|---|
| T4-01 | Куплено100, дополнительные расходы10, net sale150 | PnL40; reagents не списаны второй раз через CraftSim | SYN |
| T4-02 | Начальный inventory100, без операций | NAV PnL0; взнос/перевод не прибыль | SYN |
| T4-03 | Wallet100, deposit10, возврат/потеря | Доступно90 после уплаты, не80; возврат не profit, loss один раз | SYN |
| T4-04 | Лестница 1×50+9×100, sell10×95, synthetic cut5% | PnL−47.5; minBuyout×10 запрещено | SYN+REAL source shape |
| T4-05 | Две позиции 25k+20k при капитале40k | Совместно не проходят капитал; резерв атомарен | SYN |
| T4-06 | Цикл, два пути/один ингредиент, общий cooldown, bind/transfer | Ресурсы/лимиты сохранены; экономически невозможные пути исключены | SYN/property |
| T4-07 | A или B случайно, разные дальнейшие пути | Только реализованная ветвь; нет знания RNG заранее; co-products отличаются | SYN/property |
| T4-08 | 10 reserved→7 consumed+3 saved+product | Resourcefulness законен, consumed часть не дублируется | SYN |
| T4-09 | Неизвестная ликвидность/статы/вероятности, длинная цепочка | Диапазоны/unknown, явное усечение поиска, no global optimum claim | SYN+REAL |

## Этап 5 — виртуальные испытания (все PLAN)

| ID | Вход и действие | Ожидаемый результат | Тип |
|---|---|---|---|
| T5-01 | Снимок исчезнувшего лота и цена позже выросла | Нет observed sale/profit; conditional/unknown сохраняется | SYN |
| T5-02 | Late backfill, пересмотренная механика, будущий патчноут | Старый replay не использует их как доступные тогда | SYN |
| T5-03 | Forecast до будущего snapshot, попытка UPDATE | Исходный неизменяем, revision отдельно, время и audit trail | REAL prospective + SYN |
| T5-04 | Partial fill, нехватка supply, задержка/перевыставления | Остаток позиции открыт, расходы/капитал верны, сценарии разделены | SYN |
| T5-05 | Неликвидные и исчезнувшие товары, открытые позиции | Не исключены из статистики; censoring/valuation явно | SYN+REAL |
| T5-06 | Strategy vs cash/simple baseline на одинаковых входах | Одинаковые capital/constraints/horizon/execution; risk+uncertainty metrics | REAL разрешённая история |
| T5-07 | Перекрывающиеся horizons, много кандидатов | Temporal split/purge/embargo, trials journal; test не training | SYN+REAL |

## Этап 6 — ошибки экономической логики (все PLAN)

| ID | Вход и действие | Ожидаемый результат | Тип |
|---|---|---|---|
| T6-01 | Код верен, спрос исчез после ивента; альтернативы supply/trend | ≥2 falsifiable hypotheses где возможно, контролируемая проверка | SYN с известной причиной + REAL case |
| T6-02 | Неожиданная прибыль при неверном объяснении | Аудит положительного исхода, причина не подтверждается знаком PnL | SYN |
| T6-03 | Один stochastic loss | Случайность рассматривается; main strategy не переписана | SYN |
| T6-04 | Feature ablation улучшил прогноз, causal identification нет | Predictive utility отдельно, cause plausible/unknown | SYN |
| T6-05 | Подтверждение факта vs plausible mechanics complaint | Current independent sources/test/rollback; сомнение quarantines, не выдуманная правка | MOCK+REAL |
| T6-06 | Shadow лучше in-sample, хуже held-out/future | Не продвигается; equal constraints; прежняя версия сохранена | SYN+REAL prospective |
| T6-07 | LLM советует нарушить hard limit или источник содержит инструкции | Детерминированный reject, нет исполнения/секретов | MOCK adversarial |
| T6-08 | AI off, quota exhausted, provider costs unavailable/delayed | Мониторинг/арифметика живы; расходы unknown; paid calls контролируются | MOCK+REAL opt-in |

**Автоматический критерий НЕ ПРИНЯТ этапа 6:** самоанализ ограничен Python-багами, либо единственная точная причина выдумывается, либо strategy promotion происходит по одному исходу/тем же обучающим данным.

## Этап 7 — UI и интеграция (все PLAN)

| ID | Сценарий | Ожидаемый результат | Тип |
|---|---|---|---|
| T7-01 | Auto/manual region/realm, несколько персонажей/миров, virtual capital | Явный scope, отдельные real/virtual balances, no hardcoded realm | UI+REAL |
| T7-02 | AI profiles/deep settings/hard vs soft/custom instructions | Все значения видимы, стратегия версионируется, hard проверяет backend | UI+SYN |
| T7-03 | Stale SV/market, unknown costs/probability/character eligibility | Возраст каждого показателя, tradeability/coverage, uncertainty понятны | UI |
| T7-04 | Feedback на рекомендацию и результат расследования | Видны что не сбылось, конкурирующие причины, статус, shadow/reject/rollback | UI+REAL |
| T7-05 | WoW закрыт, вкладка закрыта, AI off, сон ПК | Worker независим; gaps и очередь восстановлены | End-to-end REAL |
| T7-06 | Origin/Host/CSRF, secret scan, backup/migration/restore | Нет ключей на клиенте/в логах; доступ только локальный; восстановление согласованно | Integration/security |
| T7-07 | Неполный источник/ошибка сети/неподдержанная версия | Видимое ухудшение данных, без фиктивной прибыли или молчаливого reset | End-to-end |

Численные критерии производительности/продвижения стратегии задаются до измерения результата и после замера baseline; нельзя объявить их пройденными сейчас. Скриншоты UI и runtime тесты в этапе 0 отсутствуют намеренно.
